export class CreateWalletAnalysisDto {}
